package co.edu.javeriana.logo.ast;



import co.edu.javeriana.logo.Scope;

public interface ASTNode {
	public Object execute(Scope symbolTable) throws Exception;
}
