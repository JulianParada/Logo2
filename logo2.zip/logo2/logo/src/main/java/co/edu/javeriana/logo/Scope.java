package co.edu.javeriana.logo;

import java.util.HashMap;

public class Scope {
	
	private HashMap<String,Object> symboltable;
	protected Scope anterior = null;
	
	public Scope()
	 {
		 symboltable = new HashMap<String, Object>();
		 
	 }
	 public Scope(Scope ant)
	 {
		 symboltable = new HashMap<String, Object>();
		 this.anterior = ant;
	 }
	 public void put(String simbolo, Object obj)
	 {
		 if(symboltable.get(simbolo)!= null)
		 symboltable.put(simbolo, obj);
		 else
		 {
			if( anterior != null)
			anterior.put(simbolo, obj); 
		 }
			 
	 }
	 public void putnew(String simbolo, Object obj)
	 {
		 symboltable.put(simbolo, obj);
	 }
	 
	 public Object get(String palabra)
	 {
		 for(Scope a = this; a!= null; a = a.anterior )
		 {
			 Object encontrado = (Object) (a.symboltable.get(palabra));
			 if (encontrado != null)
				 return encontrado;
		 }
		 return null;
	 }
}
