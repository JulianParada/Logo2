package co.edu.javeriana.logo.ast;

import co.edu.javeriana.logo.Scope;
import co.edu.javeriana.logo.Turtle;

public class RotRight implements ASTNode {
	private ASTNode operand1;
	private Turtle agente;
	
	
	public RotRight(ASTNode operand1, Turtle tr) {
		super();
		this.operand1 = operand1;
		this.agente = tr;
	}



	@Override
	public Object execute(Scope symbolTable) throws Exception {
		
		try {
			agente.right((float)operand1.execute(symbolTable));
			return null;
		}
		catch (Exception e){
		throw new Exception("No se puede usar ROTATE RIGHT con variables diferentes a Float");
		}
	}

}
