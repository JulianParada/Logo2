package co.edu.javeriana.logo.ast;


import co.edu.javeriana.logo.Scope;
import co.edu.javeriana.logo.Turtle;

public class RotLeft implements ASTNode {
	private ASTNode operand1;
	private Turtle agente;
	
	
	public RotLeft(ASTNode operand1, Turtle tr) {
		super();
		this.operand1 = operand1;
		this.agente = tr;
	}



	@Override
	public Object execute(Scope symbolTable) throws Exception {
		
		try {
			agente.left((float)operand1.execute(symbolTable));
			return null;
		}
		catch (Exception e){
		throw new Exception("No se puede usar ROTATE LEFT con variables diferentes a Float");
		}
		
	}

}
