package co.edu.javeriana.logo.ast;

import java.util.Scanner;

import co.edu.javeriana.logo.Scope;

public class Readln implements ASTNode {
	private String name;
	private String expressions;
	
	
	
	public Readln(String name) {
		super();
		this.name = name;
	}



	@SuppressWarnings("resource")
	@Override
	public Object execute(Scope symbolTable) throws Exception {
		try {
			Scanner myObj = new Scanner(System.in);
			expressions = myObj.next(); 
			symbolTable.putnew(name, expressions);
			return null;
		}
		catch (Exception e){
		throw new Exception("No se puede leer");
		}
		
	}

}
