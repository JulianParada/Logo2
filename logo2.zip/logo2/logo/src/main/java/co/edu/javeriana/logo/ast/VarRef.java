package co.edu.javeriana.logo.ast;

import co.edu.javeriana.logo.Scope;

public class VarRef implements ASTNode {

	private String name;
	
	
	
	public VarRef(String name) {
		super();
		this.name = name;
	}



	@Override
	public Object execute(Scope symbolTable) throws Exception {
		
		try {
			return symbolTable.get(name);
		}
		catch (Exception e){
		throw new Exception("No se puede usar Referenciar");
		}
	}

}
