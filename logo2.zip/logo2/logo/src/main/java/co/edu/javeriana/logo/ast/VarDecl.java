package co.edu.javeriana.logo.ast;


import co.edu.javeriana.logo.Scope;

public class VarDecl implements ASTNode {

	private String name;
	
	
	
	public VarDecl(String name) {
		super();
		this.name = name;
	}



	@Override
	public Object execute(Scope symbolTable) throws Exception {
	
		try {
			symbolTable.putnew(name, new Object());
			return null;
		}
		catch (Exception e){
		throw new Exception("No se puede usar Declarar");
		}
	}

}
