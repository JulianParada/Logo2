package co.edu.javeriana.logo.ast;

import java.util.List;

import co.edu.javeriana.logo.Scope;

public class While implements ASTNode {
	private ASTNode condition;
	private List<ASTNode> body;

	
	
	public While(ASTNode condition, List<ASTNode> body) {
		super();
		this.condition = condition;
		this.body = body;
	}



	@Override
	public Object execute(Scope symbolTable) throws Exception {
		try {
		while((boolean)condition.execute(symbolTable)) {
			Scope scopewhile = new Scope(symbolTable);
			for(ASTNode n: body) {
				n.execute(scopewhile);
			}
		}
		}
		catch(Exception e) {
			throw new Exception("Hay un problema con el While, no se puede ejecutar.");
		}
		return null;
	}

}
