package co.edu.javeriana.logo.ast;

import co.edu.javeriana.logo.Scope;

public class InvAdd implements ASTNode {
	private ASTNode operand1;
	
	
	
	public InvAdd(ASTNode operand1) {
		super();
		this.operand1 = operand1;
	}



	@Override
	public Object execute(Scope symbolTable) throws Exception {
		// TODO Auto-generated method stub
		try {
			return (float)operand1.execute(symbolTable)*-1;
			}
		catch (Exception e){
		throw new Exception("No se puede usar INV ADD (-) para expresiones diferentes a las numericas");
		}
		
	}

}
