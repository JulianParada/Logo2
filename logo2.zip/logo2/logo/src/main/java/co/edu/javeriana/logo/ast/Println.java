package co.edu.javeriana.logo.ast;


import co.edu.javeriana.logo.Scope;

public class Println implements ASTNode {
	private ASTNode data;
	
	
	public Println(ASTNode data) {
		super();
		this.data = data;
	}

	@Override
	public Object execute(Scope symbolTable) throws Exception {
		try {
			System.out.println(data.execute(symbolTable));
			return null;
		}
		catch (Exception e){
		throw new Exception("No se puede imprimir");
		}
		
	}

}
