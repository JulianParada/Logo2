package co.edu.javeriana.logo.ast;


import co.edu.javeriana.logo.Scope;

public class VarAssign implements ASTNode {

	private String name;
	private ASTNode expression;
	
	
	
	public VarAssign(String name, ASTNode expression) {
		super();
		this.name = name;
		this.expression = expression;
	}



	@Override
	public Object execute(Scope symbolTable) throws Exception {
		
		try {
			symbolTable.put(name, expression.execute(symbolTable));
			return null;
		}
		catch (Exception e){
		throw new Exception("No se puede usar asignar");
		}
	}

}
