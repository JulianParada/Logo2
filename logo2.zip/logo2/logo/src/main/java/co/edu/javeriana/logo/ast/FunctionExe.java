package co.edu.javeriana.logo.ast;

import java.util.List;

import co.edu.javeriana.logo.Scope;

public class FunctionExe implements ASTNode {

	private String name;
	private List<ASTNode> param;
	
	public FunctionExe(String name, List<ASTNode> param2) {
		super();
		this.name = name;
		this.param = param2;
	}

	@Override
	public Object execute(Scope scope) throws Exception {
		try {
			FunctionDecl declarada = (FunctionDecl)scope.get(name);
			Scope scoFun = new Scope(scope);
			List<String> NamesParams =  declarada.getParam();
			List<ASTNode> functBody = declarada.getBody();
			
			for (int i = 0; i < param.size(); i++) {
				scoFun.putnew(NamesParams.get(i), (this.param.get(i)).execute(scope));
			}
			
			for (ASTNode pr : functBody) {
				pr.execute(scoFun);
			}
			return null;
		}
		catch (Exception e){
			throw new Exception(e.getMessage());
		}
	}
}
