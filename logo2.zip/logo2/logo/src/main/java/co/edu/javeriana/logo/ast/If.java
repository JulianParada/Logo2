package co.edu.javeriana.logo.ast;

import java.util.List;


import co.edu.javeriana.logo.Scope;

public class If implements ASTNode {
	private ASTNode condition;
	private List<ASTNode> body;
	private List<ASTNode> elseBody;

	
	
	public If(ASTNode condition, List<ASTNode> body, List<ASTNode> elseBody) {
		super();
		this.condition = condition;
		this.body = body;
		this.elseBody = elseBody;
	}



	@Override
	public Object execute(Scope symbolTable) throws Exception{
		try {
			if((boolean)condition.execute(symbolTable)) {
				Scope scopeif = new Scope(symbolTable);
				for(ASTNode n: body) {
					n.execute(scopeif);
				}
			}
			else {
				Scope scopelse = new Scope(symbolTable);
				for(ASTNode n: elseBody) {
					n.execute(scopelse);
				}
			}
		}catch(Exception e) {
			throw new Exception("Hay un problema con el condiconal, no se puede ejecutar.");
		}
		return null;
	}

}
