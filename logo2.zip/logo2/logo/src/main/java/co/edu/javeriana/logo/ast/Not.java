package co.edu.javeriana.logo.ast;


import co.edu.javeriana.logo.Scope;

public class Not implements ASTNode {

	private ASTNode operand1;
	
	
	public Not(ASTNode operand1) {
		super();
		this.operand1 = operand1;
	}


	@Override
	public Object execute(Scope symbolTable) throws Exception {
		// TODO Auto-generated method stub
		
		try {
			boolean a = (Boolean)operand1.execute(symbolTable);
			return !a;			
		}
		catch (Exception e){
		throw new Exception("No se puede usar NOT (!) para variables diferentes a Boolean");
		}
	}

}
