package co.edu.javeriana.logo.ast;

import java.util.List;

import co.edu.javeriana.logo.Scope;

public class FunctionDecl implements ASTNode {

	private String name;
	private List<String> param;
	private List<ASTNode> body;
	
	public FunctionDecl(String name, List<String> param2, List<ASTNode> body2) {
		super();
		this.name = name;
		this.param = param2;
		this.body = body2;
	}

	@Override
	public Object execute(Scope symbolTable) throws Exception {
		
		try {
			symbolTable.putnew(name, this);
			return null;
		}
		catch (Exception e){
			throw new Exception("Hay un problema con la declaracion de la funcion.");
		}
	}

	public List<String> getParam() {
		return param;
	}

	public List<ASTNode> getBody() {
		return body;
	}

}
