
package co.edu.javeriana.logo;

public class LogoCustomVisitor extends LogoBaseVisitor<Object> {



}
