package co.edu.javeriana.logo.ast;

import co.edu.javeriana.logo.Scope;

public class VarDeclAss implements ASTNode {

	private String name;
	private ASTNode expression;
	
	
	
	public VarDeclAss(String name, ASTNode expression) {
		super();
		this.name = name;
		this.expression = expression;
	}



	@Override
	public Object execute(Scope symbolTable) throws Exception {
		
		try {
			
			
			symbolTable.putnew(name, expression.execute(symbolTable));

		}
		catch (Exception e){
			throw new Exception("No se puede usar Declarar y Asignar valor a la nueva variable.");
		}
		return null;


	}

}
