package co.edu.javeriana.logo.ast;


import co.edu.javeriana.logo.Scope;

public class Or implements ASTNode {

	private ASTNode operand1;
	private ASTNode operand2;
	
	
	public Or(ASTNode operand1, ASTNode operand2) {
		super();
		this.operand1 = operand1;
		this.operand2 = operand2;
	}


	@Override
	public Object execute(Scope symbolTable) throws Exception {
		// TODO Auto-generated method stub
		try {
			return (Boolean)operand1.execute(symbolTable)||(Boolean)operand2.execute(symbolTable);		
		}
		catch (Exception e){
		throw new Exception("No se puede usar OR (||) para variables diferentes a Boolean");
		}
	}

}
